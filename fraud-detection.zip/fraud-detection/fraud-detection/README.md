# 💳 Credit Card Fraud Detection

A complete machine-learning pipeline for detecting fraudulent credit card transactions using **Logistic Regression**, **Random Forest**, and **Gradient Boosting** classifiers — plus an interactive React dashboard.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3%2B-F7931E?logo=scikit-learn)
![React](https://img.shields.io/badge/React-Dashboard-61DAFB?logo=react)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 📁 Project Structure

```
fraud-detection/
├── src/
│   ├── fraud_detection.py     # Full ML pipeline (train → evaluate → plot)
│   └── fraud_detection.jsx    # Interactive React dashboard
├── utils/
│   └── helpers.py             # Threshold analysis, dataset summaries
├── notebooks/
│   └── exploration.py         # EDA + threshold study (Jupytext format)
├── data/                      # Generated CSV saved here
├── models/                    # Output plots saved here
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

```bash
# 1. Clone
git clone https://github.com/<your-username>/fraud-detection.git
cd fraud-detection

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the full ML pipeline
python src/fraud_detection.py
```

This will:
- Generate 10,000 synthetic transactions (8% fraud)
- Train 3 classifiers with balanced class weights
- Print classification reports with ROC-AUC scores
- Save plots to `models/`

---

## 🧠 Models

| Model | Description |
|-------|-------------|
| **Logistic Regression** | Baseline linear classifier with `class_weight='balanced'` |
| **Random Forest** | Ensemble of 100 decision trees |
| **Gradient Boosting** | Sequential boosting with learning rate 0.1 |

---

## 📊 Features

| Feature | Description |
|---------|-------------|
| `amount` | Transaction dollar amount |
| `hour` | Hour of day (0–23) |
| `distance` | Geographic distance from home location (km) |
| `velocity` | Transactions per hour in rolling window |
| `v1`, `v2`, `v3` | PCA-derived anonymised components |

---

## 📈 Output Plots

| File | Description |
|------|-------------|
| `models/confusion_matrix.png` | TP / FP / FN / TN breakdown |
| `models/roc_curves.png` | ROC curves for all 3 models |
| `models/feature_importance.png` | Feature weights / importances |

---

## 🖥️ React Dashboard

An interactive browser dashboard lives in `src/fraud_detection.jsx`.  
Open it in [Claude.ai Artifacts](https://claude.ai) or any React sandbox:

- **Train** a logistic model in-browser on 600 synthetic transactions
- Adjust the **decision threshold** with a live slider
- **Scatter plot**, confusion matrix, and loss curve visualisations
- **Live Monitor** tab streams and scores new transactions in real time

---

## 🔬 Notebook

Convert the Jupytext script to a proper `.ipynb` notebook:

```bash
pip install jupytext
jupytext --to notebook notebooks/exploration.py
jupyter notebook notebooks/exploration.ipynb
```

Covers EDA, distribution plots, correlation heatmap, threshold analysis, and precision/recall curves.

---

## 📐 Threshold Tuning

The `utils/helpers.py` module includes `threshold_metrics()` and `best_threshold()` to find the operating point that maximises F1 (or any metric) on your validation set:

```python
from utils.helpers import best_threshold
t, f1 = best_threshold(y_test, y_prob, metric="f1")
print(f"Best threshold: {t}  →  F1: {f1:.4f}")
```

---

## 📄 License

MIT © 2024
