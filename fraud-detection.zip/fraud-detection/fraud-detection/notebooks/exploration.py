# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
# ---

# %% [markdown]
# # Credit Card Fraud Detection — Exploratory Notebook
# End-to-end walkthrough: data generation → EDA → model training → evaluation

# %%
import sys
sys.path.insert(0, "..")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from src.fraud_detection import generate_dataset, preprocess, build_models, train_all, evaluate, FEATURES
from utils.helpers import threshold_metrics, best_threshold, summarise_dataset

sns.set_theme(style="darkgrid")
plt.rcParams["figure.dpi"] = 120

# %% [markdown]
# ## 1. Generate & Explore Data

# %%
df = generate_dataset(n_samples=5000)
summarise_dataset(df)
df.head()

# %%
fig, axes = plt.subplots(1, 2, figsize=(12, 4))

# Amount distribution
for label, color in [(0, "#00E5A0"), (1, "#FF3B6B")]:
    subset = df[df.label == label]["amount"]
    axes[0].hist(subset, bins=50, alpha=0.6,
                 color=color, label=("Legitimate" if label == 0 else "Fraud"))
axes[0].set_title("Transaction Amount Distribution")
axes[0].set_xlabel("Amount ($)")
axes[0].legend()

# Hour of day
for label, color in [(0, "#00E5A0"), (1, "#FF3B6B")]:
    subset = df[df.label == label]["hour"]
    axes[1].hist(subset, bins=24, alpha=0.6,
                 color=color, label=("Legitimate" if label == 0 else "Fraud"))
axes[1].set_title("Hour of Day Distribution")
axes[1].set_xlabel("Hour")
axes[1].legend()

plt.tight_layout()
plt.show()

# %%
# Correlation heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(df[FEATURES + ["label"]].corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Feature Correlation Matrix")
plt.tight_layout()
plt.show()

# %% [markdown]
# ## 2. Train Models

# %%
X_train, X_test, y_train, y_test, scaler = preprocess(df)
models = train_all(build_models(), X_train, y_train)

for name, model in models.items():
    evaluate(model, X_test, y_test, name)

# %% [markdown]
# ## 3. Threshold Analysis

# %%
from sklearn.linear_model import LogisticRegression

lr = models["Logistic Regression"]
y_prob = lr.predict_proba(X_test)[:, 1]

thresh_df = threshold_metrics(y_test, y_prob)
print(thresh_df.to_string(index=False))

best_t, best_f1 = best_threshold(y_test, y_prob, metric="f1")
print(f"\nBest threshold = {best_t}  (F1 = {best_f1:.4f})")

# %%
plt.figure(figsize=(9, 4))
plt.plot(thresh_df.threshold, thresh_df.precision, label="Precision", color="#00D4FF", lw=2)
plt.plot(thresh_df.threshold, thresh_df.recall,    label="Recall",    color="#FF3B6B", lw=2)
plt.plot(thresh_df.threshold, thresh_df.f1,        label="F1",        color="#00E5A0", lw=2)
plt.axvline(best_t, ls="--", color="#FFB800", label=f"Best threshold ({best_t})")
plt.xlabel("Threshold"); plt.ylabel("Score")
plt.title("Precision / Recall / F1 vs Decision Threshold")
plt.legend(); plt.tight_layout(); plt.show()
