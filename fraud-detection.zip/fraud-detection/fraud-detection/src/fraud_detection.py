"""
Credit Card Fraud Detection — ML Pipeline
==========================================
Trains Logistic Regression, Random Forest, and Gradient Boosting
classifiers on synthetic transaction data and evaluates all three.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, roc_curve, average_precision_score,
)
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────
# 1. SYNTHETIC DATA GENERATION
# ─────────────────────────────────────────────

def generate_dataset(n_samples=10000, fraud_ratio=0.08, random_state=42):
    np.random.seed(random_state)
    n_fraud = int(n_samples * fraud_ratio)
    n_legit = n_samples - n_fraud

    legit = pd.DataFrame({
        "amount":   np.random.exponential(80, n_legit),
        "hour":     np.random.randint(8, 22, n_legit),
        "distance": np.random.exponential(20, n_legit),
        "velocity": np.random.exponential(1.5, n_legit),
        "v1":       np.random.normal(0, 1, n_legit),
        "v2":       np.random.normal(0, 1, n_legit),
        "v3":       np.random.normal(0, 1, n_legit),
        "label":    0,
    })

    fraud = pd.DataFrame({
        "amount":   np.random.exponential(600, n_fraud) + 200,
        "hour":     np.random.choice(range(1, 6), n_fraud),
        "distance": np.random.exponential(300, n_fraud) + 100,
        "velocity": np.random.exponential(8, n_fraud) + 5,
        "v1":       np.random.normal(2, 1.5, n_fraud),
        "v2":       np.random.normal(-2, 1.5, n_fraud),
        "v3":       np.random.normal(3, 1, n_fraud),
        "label":    1,
    })

    df = (pd.concat([legit, fraud])
            .sample(frac=1, random_state=random_state)
            .reset_index(drop=True))
    return df


# ─────────────────────────────────────────────
# 2. PREPROCESSING
# ─────────────────────────────────────────────

FEATURES = ["amount", "hour", "distance", "velocity", "v1", "v2", "v3"]

def preprocess(df):
    X, y = df[FEATURES], df["label"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )
    scaler = StandardScaler()
    return (
        scaler.fit_transform(X_train),
        scaler.transform(X_test),
        y_train, y_test, scaler
    )


# ─────────────────────────────────────────────
# 3. MODELS
# ─────────────────────────────────────────────

def build_models():
    return {
        "Logistic Regression": LogisticRegression(
            class_weight="balanced", max_iter=1000, random_state=42),
        "Random Forest": RandomForestClassifier(
            n_estimators=100, class_weight="balanced", random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(
            n_estimators=100, learning_rate=0.1, random_state=42),
    }


def train_all(models, X_train, y_train):
    for name, m in models.items():
        print(f"  Training {name}...")
        m.fit(X_train, y_train)
    return models


# ─────────────────────────────────────────────
# 4. EVALUATION
# ─────────────────────────────────────────────

def evaluate(model, X_test, y_test, name):
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    print(f"\n{'='*52}\n  {name}\n{'='*52}")
    print(classification_report(y_test, y_pred,
                                 target_names=["Legitimate", "Fraud"]))
    print(f"  ROC-AUC  : {roc_auc_score(y_test, y_prob):.4f}")
    print(f"  Avg Prec : {average_precision_score(y_test, y_prob):.4f}")
    return y_pred, y_prob


# ─────────────────────────────────────────────
# 5. PLOTS
# ─────────────────────────────────────────────

def plot_confusion_matrix(y_test, y_pred, name, out="models/confusion_matrix.png"):
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Legitimate", "Fraud"],
                yticklabels=["Legitimate", "Fraud"])
    plt.title(f"Confusion Matrix — {name}")
    plt.ylabel("Actual"); plt.xlabel("Predicted")
    plt.tight_layout(); plt.savefig(out, dpi=150); plt.close()


def plot_roc_curves(models, X_test, y_test, out="models/roc_curves.png"):
    colors = ["#00D4FF", "#FF3B6B", "#00E5A0"]
    plt.figure(figsize=(8, 6))
    for (name, model), color in zip(models.items(), colors):
        y_prob = model.predict_proba(X_test)[:, 1]
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        auc = roc_auc_score(y_test, y_prob)
        plt.plot(fpr, tpr, label=f"{name} (AUC={auc:.3f})", color=color, lw=2)
    plt.plot([0, 1], [0, 1], "k--", alpha=0.4)
    plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
    plt.title("ROC Curves — All Models")
    plt.legend(); plt.tight_layout(); plt.savefig(out, dpi=150); plt.close()


def plot_feature_importance(model, name, out="models/feature_importance.png"):
    imp = (model.feature_importances_
           if hasattr(model, "feature_importances_")
           else np.abs(model.coef_[0]))
    idx = np.argsort(imp)[::-1]
    plt.figure(figsize=(7, 4))
    plt.bar(range(len(FEATURES)), imp[idx], color="#00D4FF", alpha=0.85)
    plt.xticks(range(len(FEATURES)), [FEATURES[i] for i in idx],
               rotation=30, ha="right")
    plt.title(f"Feature Importance — {name}")
    plt.tight_layout(); plt.savefig(out, dpi=150); plt.close()


# ─────────────────────────────────────────────
# 6. MAIN
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("Credit Card Fraud Detection — ML Pipeline")
    print("=" * 52)

    print("\n[1/5] Generating dataset...")
    df = generate_dataset(10000)
    fraud_pct = df["label"].mean() * 100
    print(f"      {len(df):,} transactions | {df['label'].sum()} fraud ({fraud_pct:.1f}%)")
    df.to_csv("data/transactions.csv", index=False)
    print("      Saved → data/transactions.csv")

    print("\n[2/5] Preprocessing...")
    X_train, X_test, y_train, y_test, scaler = preprocess(df)
    print(f"      Train: {len(X_train):,} | Test: {len(X_test):,}")

    print("\n[3/5] Training models...")
    models = train_all(build_models(), X_train, y_train)

    print("\n[4/5] Evaluating models...")
    results = {name: evaluate(m, X_test, y_test, name) for name, m in models.items()}

    print("\n[5/5] Saving plots...")
    best = "Random Forest"
    plot_confusion_matrix(y_test, results[best][0], best)
    plot_roc_curves(models, X_test, y_test)
    plot_feature_importance(models[best], best)
    print("      → models/confusion_matrix.png")
    print("      → models/roc_curves.png")
    print("      → models/feature_importance.png")
    print("\n✓ Pipeline complete.")
