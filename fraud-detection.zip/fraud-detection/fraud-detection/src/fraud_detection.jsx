import { useState, useEffect, useRef } from "react";

const generateDataset = (n = 500) => {
  const data = [];
  for (let i = 0; i < n; i++) {
    const isFraud = Math.random() < 0.08;
    data.push({
      id: i,
      amount: isFraud ? Math.random() * 4800 + 200 : Math.random() * 300 + 5,
      hour: isFraud ? Math.floor(Math.random() * 6) + 1 : Math.floor(Math.random() * 14) + 8,
      distance: isFraud ? Math.random() * 900 + 100 : Math.random() * 50,
      velocity: isFraud ? Math.random() * 15 + 5 : Math.random() * 3,
      v1: (Math.random() - 0.5) * (isFraud ? 4 : 2),
      v2: (Math.random() - 0.5) * (isFraud ? 4 : 2),
      label: isFraud ? 1 : 0,
    });
  }
  return data;
};

const normalize = (val, min, max) => (val - min) / (max - min + 1e-9);

const logisticScore = (tx, weights) => {
  const z =
    weights.w0 +
    weights.w1 * tx.normAmount +
    weights.w2 * tx.normHour +
    weights.w3 * tx.normDistance +
    weights.w4 * tx.normVelocity;
  return 1 / (1 + Math.exp(-z));
};

const prepareFeatures = (data) => {
  const amounts = data.map((d) => d.amount);
  const hours = data.map((d) => d.hour);
  const dists = data.map((d) => d.distance);
  const vels = data.map((d) => d.velocity);
  const minA = Math.min(...amounts), maxA = Math.max(...amounts);
  const minH = Math.min(...hours), maxH = Math.max(...hours);
  const minD = Math.min(...dists), maxD = Math.max(...dists);
  const minV = Math.min(...vels), maxV = Math.max(...vels);
  return data.map((d) => ({
    ...d,
    normAmount: normalize(d.amount, minA, maxA),
    normHour: normalize(d.hour, minH, maxH),
    normDistance: normalize(d.distance, minD, maxD),
    normVelocity: normalize(d.velocity, minV, maxV),
  }));
};

const trainModel = (data, epochs = 200, lr = 0.3) => {
  let w = { w0: 0, w1: 0, w2: 0, w3: 0, w4: 0 };
  const history = [];
  for (let e = 0; e < epochs; e++) {
    let loss = 0;
    const grads = { w0: 0, w1: 0, w2: 0, w3: 0, w4: 0 };
    data.forEach((tx) => {
      const pred = logisticScore(tx, w);
      const err = pred - tx.label;
      loss += -(tx.label * Math.log(pred + 1e-9) + (1 - tx.label) * Math.log(1 - pred + 1e-9));
      grads.w0 += err;
      grads.w1 += err * tx.normAmount;
      grads.w2 += err * tx.normHour;
      grads.w3 += err * tx.normDistance;
      grads.w4 += err * tx.normVelocity;
    });
    Object.keys(grads).forEach((k) => {
      grads[k] /= data.length;
      w[k] -= lr * grads[k];
    });
    if (e % 10 === 0) history.push({ epoch: e, loss: loss / data.length });
  }
  return { weights: w, history };
};

const evaluate = (data, weights, threshold = 0.5) => {
  let tp = 0, fp = 0, tn = 0, fn = 0;
  const predictions = data.map((tx) => {
    const score = logisticScore(tx, weights);
    const pred = score >= threshold ? 1 : 0;
    if (tx.label === 1 && pred === 1) tp++;
    else if (tx.label === 0 && pred === 1) fp++;
    else if (tx.label === 0 && pred === 0) tn++;
    else fn++;
    return { ...tx, score, pred };
  });
  const precision = tp / (tp + fp + 1e-9);
  const recall = tp / (tp + fn + 1e-9);
  const f1 = (2 * precision * recall) / (precision + recall + 1e-9);
  const accuracy = (tp + tn) / data.length;
  return { tp, fp, tn, fn, precision, recall, f1, accuracy, predictions };
};

const COLORS = {
  bg: "#070B14",
  card: "#0D1525",
  border: "#1A2840",
  accent: "#00D4FF",
  danger: "#FF3B6B",
  safe: "#00E5A0",
  warn: "#FFB800",
  text: "#E8F4F8",
  muted: "#5A7A9A",
};

const Stat = ({ label, value, color, sub }) => (
  <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "16px 20px", minWidth: 130 }}>
    <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>{label}</div>
    <div style={{ color: color || COLORS.accent, fontSize: 28, fontWeight: 800, fontFamily: "'Space Mono', monospace", lineHeight: 1 }}>{value}</div>
    {sub && <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 4 }}>{sub}</div>}
  </div>
);

const MiniBarChart = ({ data, xKey, yKey, color }) => {
  const max = Math.max(...data.map((d) => d[yKey]));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 60 }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
          <div style={{ width: "100%", background: color || COLORS.accent, borderRadius: "3px 3px 0 0", height: `${(d[yKey] / max) * 52}px`, opacity: 0.8 }} />
        </div>
      ))}
    </div>
  );
};

const ScatterPlot = ({ predictions }) => {
  const size = 300;
  const pad = 30;
  const fraud = predictions.filter((p) => p.label === 1);
  const legit = predictions.filter((p) => p.label === 0);
  const maxA = Math.max(...predictions.map((p) => p.amount));
  const maxD = Math.max(...predictions.map((p) => p.distance));

  const px = (amount) => pad + ((amount / maxA) * (size - pad * 2));
  const py = (dist) => size - pad - ((dist / maxD) * (size - pad * 2));

  return (
    <svg width={size} height={size} style={{ background: COLORS.bg, borderRadius: 10, border: `1px solid ${COLORS.border}` }}>
      <text x={size / 2} y={16} textAnchor="middle" fill={COLORS.muted} fontSize={10} fontFamily="monospace">Amount vs Distance</text>
      {legit.slice(0, 150).map((p, i) => (
        <circle key={i} cx={px(p.amount)} cy={py(p.distance)} r={2.5} fill={COLORS.safe} opacity={0.35} />
      ))}
      {fraud.map((p, i) => (
        <circle key={i} cx={px(p.amount)} cy={py(p.distance)} r={4} fill={COLORS.danger} opacity={0.85} />
      ))}
      <text x={size - 5} y={size - 5} textAnchor="end" fill={COLORS.muted} fontSize={9} fontFamily="monospace">Amount →</text>
    </svg>
  );
};

const LossChart = ({ history }) => {
  if (!history.length) return null;
  const w = 300, h = 120, pad = 30;
  const maxL = Math.max(...history.map((h) => h.loss));
  const minL = Math.min(...history.map((h) => h.loss));
  const pts = history.map((h, i) => {
    const x = pad + (i / (history.length - 1)) * (w - pad * 2);
    const y = pad + ((1 - (h.loss - minL) / (maxL - minL + 1e-9)) * (h - pad * 2));
    return `${x},${pad + (1 - (h.loss - minL) / (maxL - minL + 1e-9)) * (h - pad * 2)}`;
  });
  return (
    <svg width={w} height={h} style={{ background: COLORS.bg, borderRadius: 10, border: `1px solid ${COLORS.border}` }}>
      <text x={w / 2} y={16} textAnchor="middle" fill={COLORS.muted} fontSize={10} fontFamily="monospace">Training Loss</text>
      <polyline points={pts.join(" ")} fill="none" stroke={COLORS.accent} strokeWidth={2} />
      <text x={pad} y={h - 5} fill={COLORS.muted} fontSize={9} fontFamily="monospace">Epoch 0</text>
      <text x={w - pad} y={h - 5} textAnchor="end" fill={COLORS.muted} fontSize={9} fontFamily="monospace">Epoch {history[history.length - 1]?.epoch}</text>
    </svg>
  );
};

const ConfusionMatrix = ({ tp, fp, tn, fn }) => {
  const total = tp + fp + tn + fn;
  const Cell = ({ val, label, color }) => (
    <div style={{ background: COLORS.bg, border: `1px solid ${color}33`, borderRadius: 8, padding: "10px 14px", textAlign: "center" }}>
      <div style={{ color, fontSize: 22, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{val}</div>
      <div style={{ color: COLORS.muted, fontSize: 10, marginTop: 2 }}>{label}</div>
    </div>
  );
  return (
    <div>
      <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>Confusion Matrix</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
        <Cell val={tp} label="True Positive" color={COLORS.safe} />
        <Cell val={fp} label="False Positive" color={COLORS.warn} />
        <Cell val={fn} label="False Negative" color={COLORS.danger} />
        <Cell val={tn} label="True Negative" color={COLORS.accent} />
      </div>
    </div>
  );
};

const LiveTransaction = ({ tx }) => {
  const risk = tx.score * 100;
  const color = risk > 70 ? COLORS.danger : risk > 40 ? COLORS.warn : COLORS.safe;
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      background: COLORS.card, border: `1px solid ${tx.pred === 1 ? COLORS.danger + "44" : COLORS.border}`,
      borderRadius: 8, padding: "8px 14px", marginBottom: 6,
      animation: "slideIn 0.3s ease"
    }}>
      <div style={{ width: 8, height: 8, borderRadius: "50%", background: color, flexShrink: 0, boxShadow: `0 0 6px ${color}` }} />
      <div style={{ flex: 1, fontFamily: "'Space Mono', monospace", fontSize: 12, color: COLORS.text }}>
        ${tx.amount.toFixed(2)}
      </div>
      <div style={{ color: COLORS.muted, fontSize: 11 }}>{tx.hour}:00</div>
      <div style={{ color: COLORS.muted, fontSize: 11 }}>{tx.distance.toFixed(0)}km</div>
      <div style={{ width: 60, background: COLORS.bg, borderRadius: 4, height: 6, overflow: "hidden" }}>
        <div style={{ width: `${risk}%`, height: "100%", background: color, transition: "width 0.3s" }} />
      </div>
      <div style={{ color, fontSize: 11, fontFamily: "'Space Mono', monospace", width: 44, textAlign: "right" }}>{risk.toFixed(0)}%</div>
      {tx.pred === 1 && <div style={{ color: COLORS.danger, fontSize: 10, fontWeight: 700, letterSpacing: 1 }}>⚠ FRAUD</div>}
    </div>
  );
};

export default function FraudDetection() {
  const [phase, setPhase] = useState("idle"); // idle | training | done
  const [dataset, setDataset] = useState([]);
  const [prepared, setPrepared] = useState([]);
  const [trainHistory, setTrainHistory] = useState([]);
  const [weights, setWeights] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [threshold, setThreshold] = useState(0.5);
  const [liveQueue, setLiveQueue] = useState([]);
  const [liveRunning, setLiveRunning] = useState(false);
  const [tab, setTab] = useState("overview");
  const liveRef = useRef(null);

  useEffect(() => {
    const d = generateDataset(600);
    setDataset(d);
    setPrepared(prepareFeatures(d));
  }, []);

  const runTraining = () => {
    setPhase("training");
    setLiveRunning(false);
    clearInterval(liveRef.current);
    setLiveQueue([]);
    setTimeout(() => {
      const { weights: w, history } = trainModel(prepared, 300, 0.4);
      setWeights(w);
      setTrainHistory(history);
      const m = evaluate(prepared, w, threshold);
      setMetrics(m);
      setPhase("done");
    }, 800);
  };

  useEffect(() => {
    if (!weights || !prepared.length) return;
    const m = evaluate(prepared, weights, threshold);
    setMetrics(m);
  }, [threshold]);

  const startLive = () => {
    if (!weights) return;
    setLiveRunning(true);
    setLiveQueue([]);
    let i = 0;
    liveRef.current = setInterval(() => {
      const isFraud = Math.random() < 0.12;
      const raw = {
        id: Date.now(),
        amount: isFraud ? Math.random() * 4800 + 200 : Math.random() * 300 + 5,
        hour: isFraud ? Math.floor(Math.random() * 6) + 1 : Math.floor(Math.random() * 14) + 8,
        distance: isFraud ? Math.random() * 900 + 100 : Math.random() * 50,
        velocity: isFraud ? Math.random() * 15 + 5 : Math.random() * 3,
        label: isFraud ? 1 : 0,
      };
      const prep = prepareFeatures([raw])[0];
      const score = logisticScore(prep, weights);
      const pred = score >= threshold ? 1 : 0;
      setLiveQueue((q) => [{ ...raw, score, pred }, ...q].slice(0, 12));
      i++;
      if (i > 40) { clearInterval(liveRef.current); setLiveRunning(false); }
    }, 400);
  };

  const stopLive = () => {
    clearInterval(liveRef.current);
    setLiveRunning(false);
  };

  const fraudCount = dataset.filter((d) => d.label === 1).length;
  const legitCount = dataset.length - fraudCount;

  const hourDist = Array.from({ length: 12 }, (_, i) => ({
    h: i * 2,
    count: dataset.filter((d) => Math.floor(d.hour / 2) === i && d.label === 1).length
  }));

  return (
    <div style={{ background: COLORS.bg, minHeight: "100vh", fontFamily: "'DM Sans', sans-serif", color: COLORS.text, padding: "0 0 40px 0" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: translateX(0); } }
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }
        ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: ${COLORS.bg}; } ::-webkit-scrollbar-thumb { background: ${COLORS.border}; }
      `}</style>

      {/* Header */}
      <div style={{ background: `linear-gradient(180deg, #0A1628 0%, ${COLORS.bg} 100%)`, borderBottom: `1px solid ${COLORS.border}`, padding: "24px 32px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
              <div style={{ width: 10, height: 10, borderRadius: "50%", background: COLORS.danger, boxShadow: `0 0 10px ${COLORS.danger}`, animation: "pulse 2s infinite" }} />
              <span style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 3, textTransform: "uppercase" }}>ML Security System</span>
            </div>
            <h1 style={{ fontSize: 26, fontWeight: 800, color: COLORS.text, letterSpacing: -0.5 }}>
              Credit Card <span style={{ color: COLORS.accent }}>Fraud Detection</span>
            </h1>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={runTraining} disabled={phase === "training"} style={{
              background: phase === "training" ? COLORS.border : COLORS.accent,
              color: phase === "training" ? COLORS.muted : COLORS.bg,
              border: "none", borderRadius: 8, padding: "10px 20px", fontWeight: 700, cursor: "pointer",
              fontSize: 13, letterSpacing: 0.5, transition: "all 0.2s"
            }}>
              {phase === "training" ? "⟳ Training..." : phase === "done" ? "↺ Retrain" : "▶ Train Model"}
            </button>
            {phase === "done" && (
              <button onClick={liveRunning ? stopLive : startLive} style={{
                background: liveRunning ? COLORS.danger + "22" : COLORS.safe + "22",
                color: liveRunning ? COLORS.danger : COLORS.safe,
                border: `1px solid ${liveRunning ? COLORS.danger : COLORS.safe}44`,
                borderRadius: 8, padding: "10px 20px", fontWeight: 700, cursor: "pointer", fontSize: 13
              }}>
                {liveRunning ? "■ Stop" : "◉ Live Monitor"}
              </button>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginTop: 20 }}>
          {["overview", "analytics", "live monitor"].map((t) => (
            <button key={t} onClick={() => setTab(t)} style={{
              background: tab === t ? COLORS.accent + "15" : "transparent",
              color: tab === t ? COLORS.accent : COLORS.muted,
              border: `1px solid ${tab === t ? COLORS.accent + "44" : "transparent"}`,
              borderRadius: 6, padding: "6px 16px", cursor: "pointer", fontSize: 12,
              fontWeight: tab === t ? 600 : 400, letterSpacing: 0.5, textTransform: "capitalize"
            }}>{t}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: "28px 32px" }}>

        {/* Overview Tab */}
        {tab === "overview" && (
          <div>
            {/* Dataset Stats */}
            <div style={{ marginBottom: 28 }}>
              <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>Dataset Overview</div>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                <Stat label="Total Transactions" value={dataset.length.toLocaleString()} color={COLORS.accent} />
                <Stat label="Fraudulent" value={fraudCount} color={COLORS.danger} sub={`${((fraudCount / dataset.length) * 100).toFixed(1)}% of total`} />
                <Stat label="Legitimate" value={legitCount} color={COLORS.safe} sub={`${((legitCount / dataset.length) * 100).toFixed(1)}% of total`} />
                <Stat label="Features" value="5" color={COLORS.warn} sub="Amount, Hour, Distance, Velocity, PCA" />
              </div>
            </div>

            {phase === "idle" && (
              <div style={{ background: COLORS.card, border: `1px dashed ${COLORS.border}`, borderRadius: 16, padding: 40, textAlign: "center" }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
                <div style={{ color: COLORS.muted, fontSize: 14 }}>Click <strong style={{ color: COLORS.accent }}>Train Model</strong> to run logistic regression on {dataset.length} transactions</div>
              </div>
            )}

            {phase === "training" && (
              <div style={{ background: COLORS.card, border: `1px solid ${COLORS.accent}33`, borderRadius: 16, padding: 40, textAlign: "center" }}>
                <div style={{ color: COLORS.accent, fontSize: 14, animation: "pulse 1s infinite" }}>⟳ Training logistic regression model...</div>
                <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 8 }}>Running gradient descent for 300 epochs</div>
              </div>
            )}

            {phase === "done" && metrics && (
              <div>
                <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>Model Performance</div>
                <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 24 }}>
                  <Stat label="Accuracy" value={`${(metrics.accuracy * 100).toFixed(1)}%`} color={COLORS.safe} />
                  <Stat label="Precision" value={`${(metrics.precision * 100).toFixed(1)}%`} color={COLORS.accent} />
                  <Stat label="Recall" value={`${(metrics.recall * 100).toFixed(1)}%`} color={COLORS.warn} />
                  <Stat label="F1 Score" value={`${(metrics.f1 * 100).toFixed(1)}%`} color={COLORS.danger} />
                </div>

                {/* Threshold Slider */}
                <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "16px 20px", marginBottom: 24 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                    <span style={{ color: COLORS.muted, fontSize: 12 }}>Decision Threshold</span>
                    <span style={{ color: COLORS.accent, fontFamily: "'Space Mono', monospace", fontSize: 14, fontWeight: 700 }}>{threshold.toFixed(2)}</span>
                  </div>
                  <input type="range" min={0.1} max={0.9} step={0.01} value={threshold}
                    onChange={(e) => setThreshold(parseFloat(e.target.value))}
                    style={{ width: "100%", accentColor: COLORS.accent }} />
                  <div style={{ display: "flex", justifyContent: "space-between", color: COLORS.muted, fontSize: 10, marginTop: 4 }}>
                    <span>← More Recalls (catch more fraud)</span>
                    <span>(fewer false alarms) More Precision →</span>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
                  <ConfusionMatrix {...metrics} />
                  <div>
                    <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>Training Loss Curve</div>
                    <LossChart history={trainHistory} />
                    <div style={{ marginTop: 16 }}>
                      <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>Fraud by Hour</div>
                      <MiniBarChart data={hourDist} xKey="h" yKey="count" color={COLORS.danger} />
                    </div>
                  </div>
                  <div>
                    <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>Transaction Clusters</div>
                    <ScatterPlot predictions={metrics.predictions} />
                    <div style={{ display: "flex", gap: 16, marginTop: 8 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                        <div style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.safe }} />
                        <span style={{ color: COLORS.muted, fontSize: 11 }}>Legitimate</span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                        <div style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.danger }} />
                        <span style={{ color: COLORS.muted, fontSize: 11 }}>Fraud</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Analytics Tab */}
        {tab === "analytics" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>
              {[
                { title: "Algorithm", val: "Logistic Regression", desc: "Binary classification with sigmoid activation. Gradient descent optimization." },
                { title: "Features Used", val: "5 Variables", desc: "Transaction amount, hour of day, geo distance, velocity, PCA-derived component." },
                { title: "Class Imbalance", val: `1:${Math.round(legitCount / fraudCount)}`, desc: "Fraud cases are rare. The model learns from imbalanced data naturally." },
                { title: "Training Split", val: "Full Dataset", desc: "600 synthetic transactions generated with realistic fraud patterns." },
              ].map((item) => (
                <div key={item.title} style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "18px 20px" }}>
                  <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>{item.title}</div>
                  <div style={{ color: COLORS.accent, fontSize: 20, fontWeight: 800, fontFamily: "'Space Mono', monospace", marginBottom: 6 }}>{item.val}</div>
                  <div style={{ color: COLORS.muted, fontSize: 12, lineHeight: 1.6 }}>{item.desc}</div>
                </div>
              ))}
            </div>

            <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "18px 20px", marginBottom: 20 }}>
              <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>Feature Importance (Weight Magnitude)</div>
              {weights && [
                { name: "Transaction Amount", w: Math.abs(weights.w1), color: COLORS.danger },
                { name: "Hour of Day", w: Math.abs(weights.w2), color: COLORS.warn },
                { name: "Geographic Distance", w: Math.abs(weights.w3), color: COLORS.accent },
                { name: "Transaction Velocity", w: Math.abs(weights.w4), color: COLORS.safe },
              ].sort((a, b) => b.w - a.w).map((f) => {
                const maxW = Math.max(Math.abs(weights.w1), Math.abs(weights.w2), Math.abs(weights.w3), Math.abs(weights.w4));
                return (
                  <div key={f.name} style={{ marginBottom: 14 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                      <span style={{ fontSize: 13, color: COLORS.text }}>{f.name}</span>
                      <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: f.color }}>{f.w.toFixed(3)}</span>
                    </div>
                    <div style={{ background: COLORS.bg, borderRadius: 4, height: 8, overflow: "hidden" }}>
                      <div style={{ width: `${(f.w / maxW) * 100}%`, height: "100%", background: f.color, borderRadius: 4, transition: "width 0.6s ease" }} />
                    </div>
                  </div>
                );
              })}
              {!weights && <div style={{ color: COLORS.muted, fontSize: 13 }}>Train the model to see feature importance.</div>}
            </div>

            <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "18px 20px" }}>
              <div style={{ color: COLORS.muted, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Fraud Patterns in Data</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
                {[
                  { label: "Avg Fraud Amount", val: `$${(dataset.filter(d => d.label === 1).reduce((s, d) => s + d.amount, 0) / (fraudCount || 1)).toFixed(0)}`, color: COLORS.danger },
                  { label: "Avg Legit Amount", val: `$${(dataset.filter(d => d.label === 0).reduce((s, d) => s + d.amount, 0) / (legitCount || 1)).toFixed(0)}`, color: COLORS.safe },
                  { label: "Peak Fraud Hour", val: "1–6 AM", color: COLORS.warn },
                ].map((s) => (
                  <div key={s.label} style={{ textAlign: "center", padding: 16, background: COLORS.bg, borderRadius: 10 }}>
                    <div style={{ color: s.color, fontSize: 22, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{s.val}</div>
                    <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 4 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Live Monitor Tab */}
        {tab === "live monitor" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600, color: COLORS.text }}>Real-time Transaction Stream</div>
                <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 2 }}>Simulated transactions scored by the trained model</div>
              </div>
              {!weights ? (
                <div style={{ color: COLORS.warn, fontSize: 12 }}>⚠ Train the model first</div>
              ) : (
                <button onClick={liveRunning ? stopLive : startLive} style={{
                  background: liveRunning ? COLORS.danger + "22" : COLORS.safe + "22",
                  color: liveRunning ? COLORS.danger : COLORS.safe,
                  border: `1px solid ${liveRunning ? COLORS.danger : COLORS.safe}44`,
                  borderRadius: 8, padding: "8px 18px", fontWeight: 700, cursor: "pointer", fontSize: 12
                }}>
                  {liveRunning ? "■ Stop Stream" : "◉ Start Stream"}
                </button>
              )}
            </div>

            {/* Legend */}
            <div style={{ display: "flex", gap: 20, marginBottom: 16, padding: "10px 14px", background: COLORS.card, borderRadius: 8, border: `1px solid ${COLORS.border}` }}>
              <span style={{ color: COLORS.muted, fontSize: 11 }}>● Risk: </span>
              {[["Low < 40%", COLORS.safe], ["Medium 40–70%", COLORS.warn], ["High > 70%", COLORS.danger]].map(([l, c]) => (
                <span key={l} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  <span style={{ color: c, fontSize: 14 }}>●</span>
                  <span style={{ color: COLORS.muted, fontSize: 11 }}>{l}</span>
                </span>
              ))}
            </div>

            <div style={{ maxHeight: 480, overflowY: "auto" }}>
              {liveQueue.length === 0 ? (
                <div style={{ textAlign: "center", padding: 60, color: COLORS.muted, fontSize: 13 }}>
                  {weights ? "Press Start Stream to monitor transactions" : "Train the model first, then start live monitoring"}
                </div>
              ) : (
                liveQueue.map((tx) => <LiveTransaction key={tx.id} tx={tx} />)
              )}
            </div>

            {liveQueue.length > 0 && (
              <div style={{ display: "flex", gap: 12, marginTop: 16, flexWrap: "wrap" }}>
                <Stat label="Flagged" value={liveQueue.filter(t => t.pred === 1).length} color={COLORS.danger} />
                <Stat label="Cleared" value={liveQueue.filter(t => t.pred === 0).length} color={COLORS.safe} />
                <Stat label="Avg Risk" value={`${(liveQueue.reduce((s, t) => s + t.score, 0) / liveQueue.length * 100).toFixed(0)}%`} color={COLORS.warn} />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
