"""Shared utility helpers for fraud detection pipeline."""

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, precision_score, recall_score


def threshold_metrics(y_true, y_prob, thresholds=None):
    """Return a DataFrame of precision/recall/F1 at multiple thresholds."""
    if thresholds is None:
        thresholds = np.arange(0.1, 0.95, 0.05)
    rows = []
    for t in thresholds:
        y_pred = (y_prob >= t).astype(int)
        rows.append({
            "threshold": round(t, 2),
            "precision": precision_score(y_true, y_pred, zero_division=0),
            "recall":    recall_score(y_true, y_pred, zero_division=0),
            "f1":        f1_score(y_true, y_pred, zero_division=0),
        })
    return pd.DataFrame(rows)


def best_threshold(y_true, y_prob, metric="f1"):
    """Find the decision threshold that maximises the given metric."""
    df = threshold_metrics(y_true, y_prob)
    idx = df[metric].idxmax()
    return df.loc[idx, "threshold"], df.loc[idx, metric]


def summarise_dataset(df, label_col="label"):
    """Print a quick summary of class distribution."""
    counts = df[label_col].value_counts()
    total  = len(df)
    print(f"Dataset summary ({total:,} rows)")
    print(f"  Legitimate : {counts.get(0, 0):,}  ({counts.get(0,0)/total*100:.1f}%)")
    print(f"  Fraud      : {counts.get(1, 0):,}  ({counts.get(1,0)/total*100:.1f}%)")
